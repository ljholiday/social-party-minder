<?php
/* Template Name: Party Minder Template */
get_header(); ?>
<div class="spm-container">
    <h1>Party Minder Placeholder</h1>
    <p>This is a layout preview for Party Minder plugin.</p>
    <?php echo do_shortcode('[spm_nav]'); ?>
</div>
<?php get_footer(); ?>
